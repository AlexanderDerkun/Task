package com.dav.weather

import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView


class CitiesAdapter(val list: MutableList<City>) : RecyclerView.Adapter<CityHolder>() {
    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int) = CityHolder(parent)

    override fun getItemCount() = list.size

    override fun onBindViewHolder(holder: CityHolder, position: Int) {
        holder.update(list[position])
    }
}