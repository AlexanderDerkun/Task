package com.dav.weather

import androidx.lifecycle.MutableLiveData
import kotlin.collections.List

object CitiesLiveData : MutableLiveData<MutableList<City>>() {
    fun addCities(cities: List<City>?) {
        val list = cities?.toMutableList() ?: return
        value?.let { value ->
            for (city in value) {
                val index = list.indexOfFirst { it.id == city.id }
                if (index == -1)
                    list.add(city)
            }
        }
        value = list
    }
}