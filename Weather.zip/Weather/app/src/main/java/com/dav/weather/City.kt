package com.dav.weather

data class City(
    val id: Int = 0,
    val name: String? = null,
    val coord: WeatherLatLng? = null,
    val main: Temperature? = null
)