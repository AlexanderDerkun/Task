package com.dav.weather

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

class CityHolder(parent: ViewGroup) :
    RecyclerView.ViewHolder(LayoutInflater.from(parent.context).inflate(R.layout.item_city, parent, false)) {
    private val tvCity: TextView = itemView.findViewById(R.id.tv_city)
    private val tvTemperature: TextView = itemView.findViewById(R.id.tv_temperature)

    init {
        itemView.setOnClickListener {
            tvTemperature.visibility = if (tvTemperature.visibility == View.VISIBLE) View.GONE else View.VISIBLE
        }
    }

    fun update(city: City) {
        tvCity.text = city.name
        tvTemperature.text = city.main?.celsius.toString()
    }
}