package com.dav.weather

import android.os.Bundle
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.lifecycle.Observer
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

class MapFragment : SupportMapFragment(), OnMapReadyCallback, Callback<WeatherResult> {
    private lateinit var map: GoogleMap

    private val client = Retrofit.Builder().baseUrl("http://api.openweathermap.org/data/2.5/").addConverterFactory(
        GsonConverterFactory.create()
    ).build()

    override fun onActivityCreated(inState: Bundle?) {
        super.onActivityCreated(inState)
        getMapAsync(this)
    }

    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setInfoWindowAdapter(object : GoogleMap.InfoWindowAdapter {
            override fun getInfoWindow(p0: Marker?): View? {
                val view = LayoutInflater.from(activity).inflate(R.layout.item_popup, null, false) as TextView
                view.text = p0?.title
                return view
            }

            override fun getInfoContents(p0: Marker?) = null
        })

        map.setOnMapClickListener {
            client.create(WeatherApi::class.java).citiesWeather(
                it.latitude,
                it.longitude,
                20, "886705b4c1182eb1c69f28eb8c520e20"
            ).enqueue(this)
        }

        CitiesLiveData.observe(this, Observer {cities ->
            map.clear()
            cities.forEach {
                val locationPos = it.coord?.googleMapLatLng ?: return@forEach
                map.addMarker(MarkerOptions().position(locationPos).title("Name: ${it.name}\nTemperature: ${it.main?.celsius}"))
            }
        })
    }

    override fun onResponse(call: Call<WeatherResult>, response: Response<WeatherResult>) {
        CitiesLiveData.addCities(response.body()?.list)
    }

    override fun onFailure(call: Call<WeatherResult>, t: Throwable) {
        Toast.makeText(activity, t.message, Toast.LENGTH_SHORT).show()
    }
}