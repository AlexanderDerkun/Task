package com.dav.weather

import android.os.Bundle
import android.util.Log
import android.view.LayoutInflater
import android.view.View
import android.widget.TextView
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.google.android.gms.maps.GoogleMap
import com.google.android.gms.maps.OnMapReadyCallback
import com.google.android.gms.maps.SupportMapFragment
import com.google.android.gms.maps.model.Marker
import com.google.android.gms.maps.model.MarkerOptions
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response
import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory
import java.util.*

class MapsActivity : AppCompatActivity(), OnMapReadyCallback, Callback<WeatherResult> {
    private lateinit var map: GoogleMap
    private val client = Retrofit.Builder().baseUrl("http://api.openweathermap.org/data/2.5/").addConverterFactory(
        GsonConverterFactory.create()
    ).build()

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        //http://api.openweathermap.org/data/2.5/find?lat=55.5&lon=37.5&cnt=10&APPID=886705b4c1182eb1c69f28eb8c520e20
        setContentView(R.layout.activity_maps)
        // Obtain the SupportMapFragment and get notified when the map is ready to be used.
        val mapFragment = supportFragmentManager
            .findFragmentById(R.id.map) as SupportMapFragment
        mapFragment.getMapAsync(this)
    }

    /**
     * Manipulates the map once available.
     * This callback is triggered when the map is ready to be used.
     * This is where we can add markers or lines, add listeners or move the camera. In this case,
     * we just add a marker near Sydney, Australia.
     * If Google Play services is not installed on the device, the user will be prompted to install
     * it inside the SupportMapFragment. This method will only be triggered once the user has
     * installed Google Play services and returned to the app.
     */
    override fun onMapReady(googleMap: GoogleMap) {
        map = googleMap
        map.setInfoWindowAdapter(object : GoogleMap.InfoWindowAdapter {
            override fun getInfoContents(marker: Marker?): View? {
               return null
            }

            override fun getInfoWindow(marker: Marker?): View {
                val popup = LayoutInflater.from(this@MapsActivity).inflate(R.layout.item_popup, null, false) as TextView
                popup.text = marker?.title
                return popup
            }
        })
        map.setOnMapClickListener {
            client.create(WeatherApi::class.java).citiesWeather(
                it.latitude,
                it.longitude,
                20,
                "886705b4c1182eb1c69f28eb8c520e20"
            ).enqueue(this)
        }
    }

    override fun onResponse(call: Call<WeatherResult>, response: Response<WeatherResult>) {
        CitiesLiveData.addCities(response.body()?.list)
        response.body()?.list?.forEach {
            val pos = it.coord?.googleMapLatLng ?: return@forEach
            map.addMarker(MarkerOptions().position(pos).title("Name: ${it.name}\nTemperature: ${it.main?.celsius}"))
        }
        Log.d("ggwp", "response: ${Arrays.toString(response.body()?.list?.toTypedArray())}")
    }

    override fun onFailure(call: Call<WeatherResult>, t: Throwable) {
    }


}
