package com.dav.weather

data class Temperature(val temp: Float = 0f) {

    val celsius get() = temp - 273f
}