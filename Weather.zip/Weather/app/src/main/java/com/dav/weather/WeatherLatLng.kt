package com.dav.weather

import com.google.android.gms.maps.model.LatLng

data class WeatherLatLng(val lat: Double = 0.0, val lon: Double = 0.0) {
    val googleMapLatLng get() = LatLng(lat, lon)
}