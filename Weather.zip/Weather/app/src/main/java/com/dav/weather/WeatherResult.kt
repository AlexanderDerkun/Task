package com.dav.weather

import kotlin.collections.List

data class WeatherResult(
    val message: String? = null,
    val cod: Int = 0,
    val list: List<City> = mutableListOf()
)